const cloud=require('wx-server-sdk')
cloud.init({
  env:'hi-3861-test-7g1kh3o98b0887c0'
})
exports.main=async(event,context)=>{
  try{
    const wxContext = cloud.getWXContext()
    //console.log(wxContext)//res就将appid和openid返回了
    return {
      event,
      openid: wxContext.OPENID,
      appid: wxContext.APPID,
      unionid: wxContext.UNIONID,
  }
    // const result=await cloud.openapi.subscribeMessage.send({
    //   touser:event.openid,
    //   page:'pages\index\index',//要填转到那个小程序页面
    //   data:{       
    //      name1:{
    //       value:"张三"
    //     },
    //     // time3:{
    //     //   value:'ajjj'
    //     // },
    //     thing4:{
    //       value:"请注意安全"}
    //     },
    //   templateId:'ocEq9xW-5a3NZ_gn4mbbIwZHeYNJqNTrJeKkf1c-3n0'
    // })
    // console.log(result)
    // return result
  }catch(err){
    console.log(err)
    return err
  }
}
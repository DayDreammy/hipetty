// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "hi-3861-test-7g1kh3o98b0887c0"
})

// 云函数入口函数
// exports.main = async (event, context) => {
//   const wxContext = cloud.getWXContext()

//   return {
//     event,
//     openid: wxContext.OPENID,
//     appid: wxContext.APPID,
//     unionid: wxContext.UNIONID,
//   }
// }

exports.main=async(event,context)=>{
        try{
          // const {openid} = cloud.getWXContext();// 在云开发数据库中存储用户订阅的课程
          const result=await cloud.openapi.subscribeMessage.send({
            touser:event.openid,
            page:'pages/TencentCloud/TencentCloud',//要填转到那个小程序页面
            data:{        
              name1:{
                value:"大橘"
              },
              thing4:{
                value:"已经超过3min没出现啦"}
              },
            templateId:"ocEq9xW-5a3NZ_gn4mbbIwZHeYNJqNTrJeKkf1c-3n0",
            miniprogramState: 'developer'
          })
          console.log(result)
          return result
        }catch(err){
          return err
        }
      }

// exports.main=async(event,context)=>{
//   try{
//     // const {openid} = cloud.getWXContext();// 在云开发数据库中存储用户订阅的课程
//     const result=await cloud.openapi.subscribeMessage.send({
//       touser: OPENID,
//         page: index,
//         lang: zh_CN,
//         data: { name1:{
//           value:'张三'},
//          thing4:{
//            value:'请注意安全'}
//          },
//         templateId: 'ocEq9xW-5a3NZ_gn4mbbIwZHeYNJqNTrJeKkf1c-3n0',
//         miniprogramState: 'developer'
//       })
//     return result
//   } catch (err) {
//     return err
//   }
// }
// pages/tera/tera/js
//连接数据库
const db = wx.cloud.database()
Page({

    // 初始数据
    data :{
        day:0,
        hour:0,
        array:[]
    },

    //使用云函数
    add:function(e){

        console.log(e);
        wx.cloud.callFunction({

            name: 'useroption',
            data: {
              option: 'add',
              addData:{
                day:16,
                hour:22
              }
            },
      
            success: res => {
              wx.showToast({
                title: '数据添加成功',
              })
              console.log("添加成功")
              console.log(res)
            },
            fail: err => {
              console.log("添加失败")
            }
          })
        },


    //查询数据（查）
    
      searchDataNameFn:function(){
        wx.cloud.callFunction({
          name: 'useroption',
          data: {
            option: 'get',
            getname:this.data.getname
          },
          success: res => {
            this.setData({
              array: res.result.data
            })
            wx.showToast({
              title: '数据查询成功',
            })
            console.log(res.result.data)
          },
          fail: err => {
            console.log(err)
          }
        })
        },

})
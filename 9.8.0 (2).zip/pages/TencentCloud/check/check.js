// pages/TencentCloud/check/check.js
//云数据库初始化
const db = wx.cloud.database({});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    feed_list:[],
    sdate:'',
    edate:''

  },

  onReady: function () {
    var that = this;
    var tm = that.getDate()
    that.setData({
      sdate:tm,
      edate:tm
    })
 
  },
  //登记信息查询
  queryUser:function(){
    //把时间接受过来传给user页面
    var sdate=this.data.sdate
    var edate = this.data.edate
  },
  
   //账单信息查询
   bindSDateChange: function (e) {
    this.setData({
      sdate: e.detail.value
    })},
    bindEDateChange: function (e) {
      this.setData({
        edate: e.detail.value
      })
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    that.setData({                 //this.setData的方法用于把传递过来的id转化成小程序模板语言
      sdate: options.sdate,         
      edate: options.edate,
    })

    //查询数据库中的表信息显示在页面上面
    //日期查询
    //1、引用数据库
    const db = wx.cloud.database({});
    const cont = db.collection('feed_list');
    //2、开始查询数据了  news对应的是集合的名称
    const _ = db.command

    cont.where({
      day: _.gte(that.data.sdate).and(_.lte(that.data.edate))
    }).get({
       //如果查询成功的话
       success: res => {
        //这一步很重要，给ne赋值，没有这一步的话，前台就不会显示值
        var list = res.data
        //这一步很重要，给ne赋值，没有这一步的话，前台就不会显示值
        that.setData({
          feed_list: list
        })
      }
    })

    // var _this=this;
    // db.collection('feed_list').where({
    //   who: 0
    // })
    // .get({
    //   success: res => {
    //     // console.log(res.data)
    //     // console.log(this)
    //     console.log(res.data[0]);
    //     this.setData({
    //       feed_list:res.data
    //     })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})